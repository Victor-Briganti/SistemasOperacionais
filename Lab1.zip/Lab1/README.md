# Laboratorio 1

Compilar o kernel do Linux.

O que precisa ser feito:

- [] Fazer introdução
- [] Fazer fundamentação
- [] Fazer discussão de resultados
- [] Fazer conclusões
- [] Refazer imagem das partições. **Deveria ser 50 GB** está com apenas 22.
- [] Revisar escrita
- [] Revisar citações
- [] Refazer tópico sobre configuração de repositórios
